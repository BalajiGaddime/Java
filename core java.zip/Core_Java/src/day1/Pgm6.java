package day1;

public class Pgm6 {

	public static void main(String[] args) {
		
		double s=700000,a,b,c;
		double tax;
		if(s<=180000){
			tax=0;
			System.out.println("tax is 0");}
			else if(s>180000 && s<=500000)
			{
				a=((s-180000)*0.1);
						tax=a;
						System.out.println("tax is:" +tax);
			}
			else if(s>500000 && s<=800000)
			{
				a=((s-500000)*0.2);
				b=((320000)*0.1);
				tax=a+b;
				System.out.println("tax is:" +tax);
			}
			else if(s>800000) {
				a=((300000)*0.2);
				b=((320000)*0.1);
				c=((s-800000)*0.3);
				tax=a+b+c;
				System.out.println("tax is:" +tax);
		
			}
			
		
		}

	}


