package day1;

public class Pgm5 {

	public static void main(String[] args) {
		
		int a=2, b=5, c=11;
		if(a<b)
			if(a<c)
				System.out.println(a);
			else
				System.out.println(c);
		else if(b<c)
			System.out.println(b);
		else
			System.out.println(c);
		}
	}


