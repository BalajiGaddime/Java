package day1;

public class Pgm16 {

	public static void main(String[] args) {
		int n=1234,r,s=0;
		while(n>0)
		{
			r=n%10;
			s=(s*10)+r;
			n=n
					/10;
		}
		while(s>0)
		{
			s=
		}

	}

}
