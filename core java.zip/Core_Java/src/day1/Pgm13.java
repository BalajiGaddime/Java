package day1;

public class Pgm13 {

	public static void main(String[] args) {
		int i,j=2,mul=1;
		
		for(i=5; i<=9; i++) {
			j=j+2;
			mul=j*i;
			System.out.println(i+ "*" +j+ "=" +mul);
			
		}
		
		
	}

}
