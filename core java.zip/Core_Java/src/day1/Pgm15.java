package day1;

public class Pgm15 {

	public static void main(String[] args) {
		int n=12345,r=0;
		while(n>0)
		{
			
			r++;
			n=n/10;
		}
		System.out.println(r);

	}

}
