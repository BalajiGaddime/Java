package day1;

public class Pgm14 {

	public static void main(String[] args) {
		int i,a=0,b=1,c=0;
		for(i=0;i<10;i++) {
			c=a+b;
			a=b;
			b=c;
			System.out.print(a+ " ");
		}
		
		
		
		
	}

}
