package day1;

public class Pgm12 {

	public static void main(String[] args) {
		int n=15;
		
		while(n<75)
		{
			if(n%7==0) {
				System.out.print(n+ " ");}
			n++;
		}

	}

}
