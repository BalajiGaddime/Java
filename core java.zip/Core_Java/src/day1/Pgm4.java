package day1;

public class Pgm4 {

	public static void main(String[] args) {
		
		int a=10,b=20,c=3;
		if(a<b&&a<c)
			System.out.println(a +"is smallest no");
		else if(b<a&&b<c)
			System.out.println(b +"is smallest no");
		else
			System.out.println(c +"is smallest no");



	}

}
