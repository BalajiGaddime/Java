package day4;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class P3 {

	public static void main(String[] args) {


		try {
			FileInputStream fin = new FileInputStream("C:\\Users\\BLTuser.BLT0191\\software\\demo.txt");
			int i;
			//i=fin.read();
			//System.out.println((char)i);
			while((i=fin.read())!=-1)
			{
				System.out.print((char)i);
			}
			fin.close();
			FileOutputStream fout = new FileOutputStream("C:\\Users\\BLTuser.BLT0191\\software\\demo.txt");
			//fout.write(65);
			byte[] d= "I am learnig java".getBytes();
			fout.write(d);
			fout.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}

}
