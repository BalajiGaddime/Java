package day4;

public class Icici extends Bank {
	
	public float get_roi()
	{
		return 7.5f;
	}


}
