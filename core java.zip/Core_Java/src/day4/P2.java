package day4;

import java.util.Scanner;

public class P2 {
	
	static String[][] emp= {{"11", "balaji"}, {"12", "uttam"}, {"13", "kishore"}, {"14", "ram"}, {"15", "mohan"}};
	static int[][] marks= {{15,95,78},{11,65,25},{13,56,48},{12,56,25},{14,48,93}};
	
	
	public static  int calc_avg(int i)

	{
		int avg;
		avg=(marks[i][1]+marks[i][2])/2;
		return avg;
	}
	public static  int search(String empid)
	{
		int index=0;
		
		int id=Integer.parseInt(empid);
		for(int i=0;i<=2;i++)
		{
			if(id==marks[i][0])
				{
				index=i;
				break;
				
				}
		}
		return index;
		
	}
		
	public static String getname(String empid)
	{
		String n = null;
		for(int j=0;j<=9;j++)
		{
			if(empid.equals(emp[j][0]))
			{
				n=emp[j][1];
				break;
				
			}
		}return n;
	}
	
	public static void main(String[] args) {
	
		int k=search("11");
		int id=Integer.parseInt("11");
		int average=P2.calc_avg(k);
		String name=P2.getname("11");
		System.out.println(id+" " +average+ " " +name+ " ");
		
		
		
	}
	

}
