package day4;

import java.util.Scanner;

public class P1 {

	public static void main(String[] args) {
		String[][] emp= {{"e1", "balaji"}, {"e2", "uttam"}, {"e3", "kishore"}, {"e4", "ram"}, {"e5", "mohan"}};
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the employee id");
		String s=sc.next();
		for(int i=0; i<=4; i++)
		{
			int k=emp[i][0].compareTo(s);
			if (k==0)
			{
				System.out.println(" emp name is " +emp[i][1]);
			}
		}
	}

}
