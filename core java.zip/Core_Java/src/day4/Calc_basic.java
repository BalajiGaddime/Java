package day4;

public class Calc_basic {
	public int add(int x, int y)
	{
		int z=x+y;
		System.out.println("2 para");
		return z;
	}
	
	public int add(int a, int b, int c)
	{
		int g=a+b+c;
		System.out.println("3 para");
		return g;
	}

	public static void main(String[] args) {
		Calc_basic calc=new Calc_basic();
	
	
		System.out.println(calc.add(5, 6));
		System.out.println(	calc.add(5, 6, 8));
		
		
	}

}
