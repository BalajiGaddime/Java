package day4;

public class student {

	int id;
	String name;
	int selenium;
	int java;
	float avg;
	
		public student(int selenium, int java) {
			System.out.println("object created");
			this.java=java; this.selenium=selenium;
		}
		public void calc_avg()
		{
			avg=(selenium+java)/2;
		
	}

}
