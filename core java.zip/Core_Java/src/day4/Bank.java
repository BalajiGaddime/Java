package day4;

public class Bank {
	public float get_roi()
	{
		return 0f;
	}
	
	public void show()
	{
		System.out.println("bank details");
	}
}
