package day4;

public class Collage {

	public static void main(String[] args) {
		
		student balaji=new student(80,90);
		/*balaji.selenium=55;
		balaji.java=65;*/
		
		
		balaji.calc_avg();
		System.out.println(balaji.avg);
		
		student uttam=new student(60,70);
		/*uttam.selenium=74;
		uttam.java=85;*/
		
		uttam.calc_avg();
		System.out.println(uttam.avg);
		
		student kishore=new student(60,70);
		kishore.calc_avg();
		System.out.println(kishore.avg);

	}

}
