package day3;

public class Advanced_calc extends Basic_calc{
	int mul;
	
	
	public void mul() {
		super.add();
		super.sub();
		mul=num1*num2;
		System.out.println(" multiplication is: " +mul);
	}
	

}
