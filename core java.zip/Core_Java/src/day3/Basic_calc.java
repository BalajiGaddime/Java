package day3;

public class Basic_calc {
	int num1,num2, add, sub;
	
	public void add() {
		add=num1+num2;
		System.out.println(" addition is: " +add);
	}
	public void sub() {
		sub=num1-num2;
		System.out.println(" substraction is: " +sub);

	}

}
