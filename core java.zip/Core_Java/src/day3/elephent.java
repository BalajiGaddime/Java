package day3;

public class elephent extends Animal {
	int lotrunk, lotusk;
	
	public void display_details() {
		super.display();
		System.out.println(" lotrunk is: " +lotrunk + " lotusk is: " +lotusk);
	}

}
