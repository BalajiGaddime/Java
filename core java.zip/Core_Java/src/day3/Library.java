package day3;

public class Library {
	public float add(int x, float y) {
		float z=x+y;
		return z;
	}

}
