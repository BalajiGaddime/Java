package day3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel1 {

	public static void main(String[] args) {
		
		File f=new File("C:\\Users\\BLTuser.BLT0191\\software\\demo1.xlsx");
		
		try {
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row = sh.getRow(0);
			XSSFCell cell = row.getCell(0);
			String s = cell.getStringCellValue();
			System.out.println(s);
			
			
			XSSFSheet sh1 = wb.getSheet("Sheet2");
			XSSFRow row1 = sh1.getRow(0);
			XSSFCell cell1 = row1.getCell(0);
			/*String s1 = cell1.getStringCellValue();
			System.out.println(s1);*/
			
			cell1.setCellValue(s);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			
		 } catch(IOException e) {
			 e.printStackTrace();
			 
		 }
		
		

}
}
