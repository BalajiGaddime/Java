package day3;
import java.util.Scanner;
public class P1 {

	public static void main(String[] args) {
		System.out.println("Enter a string");
		
		int m=0;
		Scanner input=new Scanner(System.in);
		
		char c1= input.next().charAt(0);
		
	
			while(c1!='n')
				{
				
				
				if(c1=='a'|| c1=='e'|| c1=='i'||c1=='o'|| c1=='u') {
					
					m++;
					
					}
				c1= input.next().charAt(0);
				}
			
		System.out.println(m);
	}

}
