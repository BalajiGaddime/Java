package day3;

public class Zoo {

	public static void main(String[] args) {
		elephent e1=new elephent();
		e1.height=6;
		e1.colour="gray";
		e1.weight=300;
		e1.age=6;
		e1.lotrunk=2;
		e1.lotusk=3;
		e1.gender='m';
		e1.display_details();
		
	}

}
