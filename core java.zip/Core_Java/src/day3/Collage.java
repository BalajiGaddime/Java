package day3;

public class Collage {

	public static void main(String[] args) {
		
		student balaji=new student();
		balaji.selenium=55;
		balaji.java=65;
		
		
		balaji.calc_avg();
		System.out.println(balaji.avg);
		
		student uttam=new student();
		uttam.selenium=74;
		uttam.java=85;
		uttam.calc_avg();
		System.out.println(uttam.avg);
		
	}

}
