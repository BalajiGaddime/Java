package day3;

public class Result {

	public static void main(String[] args) {
		Advanced_calc c= new Advanced_calc();
		c.num1=5;
		c.num2=2;
		
		c.mul();
		
	}

}
