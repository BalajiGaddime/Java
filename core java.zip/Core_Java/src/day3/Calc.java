package day3;

public class Calc extends Library {

	public static void main(String[] args) {
		
		Calc c= new Calc();
		float d=c.add(3, 6.5f);
		System.out.println(d);		
		
	}

}
