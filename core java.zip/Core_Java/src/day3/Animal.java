package day3;

public class Animal {
	int age, height, weight;
	String colour;
	char gender;
	public void display() {
		System.out.println(" age is: " +age+ " gender is" +gender+ " height is: " + height+ " weight is: " + weight + " colour is: " +colour);

	}
	

}
