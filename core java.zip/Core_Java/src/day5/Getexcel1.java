package day5;

import java.io.FileOutputStream;
import java.io.IOException;

public class Getexcel1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Getexcel d =new Getexcel();
		Writeexcel n=new Writeexcel();
		
		String filename="C:\\Users\\BLTuser.BLT0191\\software\\demo.xlsx";
		String sheetname="Sheet1";
		String sheetname2="Sheet2";

		int r=0;
		int c=0;
		

		String value="india is my country";
		
		String g= d.getexcel( filename,  sheetname, r, c);
		System.out.println(g);
		
		n.writeexcel( filename, sheetname2, r, c ,value);
		
		
		
		
	}

}
