package day5;

public class rectangle implements Drawable{
	
	public void draw() {
		System.out.println("draw rectangle");
	}

}
