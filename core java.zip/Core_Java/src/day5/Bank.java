package day5;

public abstract class Bank {
	public abstract float get_roi();
	
	
	public void show()
	{
		System.out.println("bank details");
	}
}
