package day5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Writeexcel {
	
	public void writeexcel(String filename, String sheetname2, int r, int c, String value) {
	File f=new File(filename);
	try {
	FileInputStream fis =new FileInputStream(f);
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	XSSFSheet sh = wb.getSheet(sheetname2);
	XSSFRow row = sh.getRow(r);
	XSSFCell cell = row.getCell(c);
	
	cell.setCellValue(value);
	FileOutputStream fos = new FileOutputStream(f);
	wb.write(fos);
	
	}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
}
