package day5;

import java.util.ArrayList;

public class Str_al {

	public static void main(String[] args) {
		ArrayList<String> str_al = new ArrayList<String>();
		
		str_al.add("BALAJI");
		str_al.add("UTTAM");
		str_al.add("KISHORE");
		str_al.add("MOHAN");
		
		
		System.out.println("Befor insertion: " +str_al);
		str_al.add(2, "ram");
		System.out.println("After Insertion: " +str_al);
		str_al.remove("KISHORE");
		System.out.println("After Deletion: " +str_al);
		str_al.remove(3);
		System.out.println("After Deletion: " +str_al);
		
		for(String s : str_al)
		{
			System.out.println(s);
		}
		
	}

}
