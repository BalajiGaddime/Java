package day5;

import java.util.ArrayList;

public class Arraylist_demo {
	
	ArrayList<student> a =new ArrayList<student>();
	
	public void create_al()
	{
		student s1 = new student("balaji", 101, 80, 64);
		student s2 = new student("uttam", 98, 65, 78);
		
		a.add(s1);
		a.add(s2);
	}
	public void display_al()
	{
		for(student s : a){
			{
				System.out.println("name: " +s.name+ " id: " +s.id+ " selenium marks : " + s.selenium + " java marks : " + s.java+ " Avg: " +s.calc_avg());
			}
		}
		
	}
	public static void main(String[] args) {
		Arraylist_demo g = new Arraylist_demo();
		g.create_al();
		g.display_al();
		
	}

}
