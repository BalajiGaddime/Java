package day5;

public class Test_bank {

	public static void main(String[] args) {
		
		Bank b;
		b= new Icici();
		System.out.println("icici roi: " +b.get_roi());
		
		b= new Hdfc();
		System.out.println("icici roi: " +b.get_roi());
	}

}
