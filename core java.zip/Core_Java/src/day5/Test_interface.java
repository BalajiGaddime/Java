package day5;

public class Test_interface {

	public static void main(String[] args) {
		
		Drawable d= new rectangle();
		d.draw();
	}

}
