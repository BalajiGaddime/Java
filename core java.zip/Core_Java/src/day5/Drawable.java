package day5;

public interface Drawable {
	void draw();
}
