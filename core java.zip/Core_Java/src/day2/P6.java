package day2;

public class P6 {

	public static void main(String[] args) {
		String s="I am learning core java";
		int v=s.length();
		int p1=0,p2 = 0;
		
		int i=0;
		while(p2>=0)
		{
			p2=s.indexOf(" ", i);
			if(p2>0) {
			String s1 = s.substring(p1,p2);
			p1=p2;
			i=p2+1;
			System.out.println(s1);}
		}
		String s2=s.substring(p1,v);
		System.out.println(s2);
		
		
	}

}
