package day2;

public class P4 {

	public static void main(String[] args) {
		String s="Chennai", s1="Chennai", s2="chennai", s3;
		
		int l=s.length();
		System.out.println("length of s is" +l);
		int v=s.compareTo(s2);
		System.out.println(v);
		
		s3=s.substring(0,4);
		System.out.println("substring:" +s3);
		
		int p=s.indexOf("n", 0);
		System.out.println("position:" +p);
		
		int p1=s.indexOf("n", p+1);
		System.out.println("position:" +p1);
		
		
	}

}
