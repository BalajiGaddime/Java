package day2;

public class P2 {

	public static void main(String[] args) {
		int[] marks= {61,56,7,25,46,34,11,25};
		int sum=0;
		for(int i=0; i<=7; i=i+2) {
			if(marks[i]%2==1)
				sum=sum+marks[i];}
		System.out.println(sum);
		
	}

}
