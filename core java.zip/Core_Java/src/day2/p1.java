package day2;

public class p1 {

	public static void main(String[] args) {
		int[] marks= {10,20,30,40,50,66,70,80,90,100};
		int i;
		float sum=0,avg;
		for(i=0;i<=9;i++)
		{
			sum=sum+marks[i];
		}
		avg=sum/10;
		System.out.println(avg);
		
		if(avg>=60 && avg<70)
			System.out.println("first class");
		else if(avg>=70)
			System.out.println("first class with dist");
		else if(avg>=50 && avg<60)
			System.out.println("second class");
		else
			System.out.println("pass");
		
	}

}
