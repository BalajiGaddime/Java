package day2;

public class P8 {

	public static void main(String[] args) {
		
		int a=10, b=0,c;
		int[] m = {1,2,3,4};
		try
		{
		System.out.println("BALAJI");
		c=a/b;
		System.out.println("REDDY");
		}
		catch(Exception e)
		{
			System.out.println("in catch block");
		}
		System.out.println(m[2]);
	}

}
