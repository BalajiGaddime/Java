package day2;

public class P5 {

	public static void main(String[] args) {
		String s="I am learning core java";
		int c=0,p=0;
		
		int i=0;
		while(p>=0)
		{
			p=s.indexOf(" ", i);
			c++;
			
			i=p+1;
		}
		c=c-1;
		System.out.println("total no of spaces are  " +c);
		
	}

}
