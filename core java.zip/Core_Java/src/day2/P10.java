package day2;

public class P10 {

	public static void main(String[] args) {
		
		int[][] m={{18,4,-2,29},{-8,99,23,18},{199,67,309,47}};
		
		for(int i=0;i<=2;i++)
			
			{
				if(m[i][0]>m[i][1] && m[i][0]>m[i][2] && m[i][0]>m[i][3])
				System.out.println(m[i][0]);
				else if(m[i][1]>m[i][2] && m[i][1]>m[i][3])
				System.out.println(m[i][1]);
				else if(m[i][2]>m[i][3])
				System.out.println(m[i][2]);
				else
					System.out.println(m[i][3]);
				
				
			}
		
		
		
	}

}
