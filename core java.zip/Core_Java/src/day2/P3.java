package day2;

public class P3 {

	public static void main(String[] args) {
		int [][] m= {{75,82,80},{81,96,95}};
		int sum=0;
				
				for(int i=0;i<=1;i++)
					for(int j=0;j<=2;j++)
					if(m[i][j]%2==0)
					{
						sum=sum+m[i][j];
					}
		System.out.println(sum);
	}

}
