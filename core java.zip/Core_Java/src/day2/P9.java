package day2;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

public class P9 {
public static void main(String[] args) {
		
		int a=10, b=2,c;
		int[] m = {1,2,3,4};
		try
		{
			c=a/b;
			System.out.println(m[5]);
			
		}
		catch(ArithmeticException ae)
		{
			System.out.println("arithmetic exception");
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("array exception");
		}

}}
