package day2;

public class P11 {

	public static void main(String[] args) {
		int num=17
				;
		boolean prime=true;
		
		for(int x=2; x<=num/2; x++) {
			int r=num%x;
			if(r==0)
			{
				prime=false;
				break;
				
			}
			
		}
		if(prime==true)
			System.out.println("prime no");
		else
			System.out.println("not prime no");
		
		
	}

}
