package day2;

public class P7 {

	public static void main(String[] args) {
		
		int a=10, b=2,c;
		int[] m = {1,2,3,4};
		
		c=a/b;
		System.out.println(m[5]);
		
	}

}
