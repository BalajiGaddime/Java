package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	
	@Given("^Browser is launched and login page displayed$")
	public void browser_is_launched_and_login_page_displayed() throws Throwable {
	   System.out.println("browser_is_launched_login_page_displayed");
	   System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	    dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
	}

	@When("^User enters login credentials and clicks on login$")
	public void user_enters_login_credentials_and_clicks_on_login() throws Throwable {
	    System.out.println("user_enters_login_credentials_and_clicks_on_login");
	    dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys("balajigaddime@gmail.com");
		
		dr.findElement(By.className("password")).sendKeys("Balaji@1996");
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		
	}

	@Then("^Successful login happens and profile name displayed correctly$")
	public void successful_login_happens_and_profile_name_displayed_correctly() throws Throwable {
	    System.out.println("successful_login_happens_and_profile_name_displayed_correctly");
	    String act_eid=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();

	    		
	    		if(act_eid.contains("balaji")==true) {
					
					System.out.println("pass");
				}
				else
					System.out.println("fail");
			
		}
	}


