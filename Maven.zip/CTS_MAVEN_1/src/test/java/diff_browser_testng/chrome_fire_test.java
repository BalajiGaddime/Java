package diff_browser_testng;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import diff_browser.chrome_fire;

public class chrome_fire_test extends chrome_fire {
	
	String url="http://demowebshop.tricentis.com";	
	WebDriver dr;
	
  @Test(priority=1)
  public void chrome() {
	  dr=chrome_fire.launch_browser("CHROME", url);
  }
  @Test(priority=3)
  public void firefox() {
	  dr=chrome_fire.launch_browser("FIREFOX", url);
  }
}
