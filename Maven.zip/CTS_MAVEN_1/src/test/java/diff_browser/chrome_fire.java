package diff_browser;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class chrome_fire {
	
	public static WebDriver launch_browser(String browser, String url)
	{
		WebDriver dr=null;
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr= new ChromeDriver();
			break;
			
		case "FIREFOX":
			System.setProperty("webdriver.gecko.driver","GeckoDriver.exe");
			dr = new FirefoxDriver();
			break;

		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		return dr;
	}
	

}
