package Grid;

import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;

public class Grid_h {
	WebDriver dr;
	String autURL, nodeURL;
	
	
	@BeforeClass
	  public void setup() throws MalformedURLException {
		autURL = "https://google.com";
//		dr.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input")).sendKeys("is duniya me sab ");
		nodeURL ="http://192.168.0.233:5566/wd/hub";
		DesiredCapabilities cap= DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		dr = new RemoteWebDriver(new URL(nodeURL), cap);
		
		
	  }
	@AfterTest
	public void aftertest()
	{
		dr.quit();
	}

  @Test
  public void test1() {
	  dr.get(autURL);
	 
  }
  
}
