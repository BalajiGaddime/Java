package kwdfm;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String kw, xpath, td;
		WebDriver dr=null;
		all_webelement_fns we= new all_webelement_fns(dr);
		get_excel excel= new get_excel();
		
		for(int r=0; r<=5; r++)
		{
			kw=excel.read_excel(r, 0);
			xpath=excel.read_excel(r, 1);
			td=excel.read_excel(r,2);
			
			switch(kw)
			{
			case "launchBrowser" :
				we.launchChrome(td);
				break;
				
			case "entertext" :
				we.enter_text(xpath, td);
				break;
				
			case "click" :
				we.click(xpath);
				break;
			
			
			case "verify" :
				we.verify(xpath, td);
				break;
				
			default :
				System.out.println("fail");
			
		}}
		

	}

}
