package kwdfm;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class get_excel {
	
	File f=new File("C:\\Users\\BLTuser.BLT0191\\software\\demo1.xlsx");
	String s=null;
	
	
	public String read_excel(int r, int c) {
	try {
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		XSSFRow row = sh.getRow(r);
		XSSFCell cell = row.getCell(c);
		
		
	
		
		
		 s = cell.getStringCellValue();
		 
		
		
	}
	
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s;
	}

}
