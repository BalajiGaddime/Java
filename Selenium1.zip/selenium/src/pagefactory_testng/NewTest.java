package pagefactory_testng;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pagefactory.demosauce_login;
import pagefactory.saucedemo_homepage;

public class NewTest {
	WebDriver dr;
	demosauce_login loginpage;
	saucedemo_homepage homepage;
	
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr= new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		
	}
	
	@Test(priority=1)
	public void title()
	{
		loginpage= new demosauce_login(dr);
		
		String c=loginpage.title();
		Assert.assertTrue(c.contains("Swag"));
	}
	
	@Test(priority=3)
	public void login()
	{
		loginpage= new demosauce_login(dr);

		loginpage.do_login("standard_user", "secret_sauce");
	}
	
	@Test(priority=4)
	public void plable()
	{
		homepage= new saucedemo_homepage(dr);
		String a=homepage.p_lable();
		
		 Assert.assertTrue(a.contains("Prod"));
	}
	
	@Test(priority=6)
	public void pname()
	{
		homepage= new saucedemo_homepage(dr);

		String b=homepage.pname();
		Assert.assertTrue(b.contains("Sauce Labs"));
		
	}
	
	
	
  
}
