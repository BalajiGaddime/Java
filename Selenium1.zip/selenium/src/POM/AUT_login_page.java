package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AUT_login_page {
	
	By uid= By.xpath("//input[@class='email']");
	By pwd= By.xpath("//input[@class='password']");
	By btn= By.xpath("//input[@value='Log in']");
	
//	By recent= By.xpath("//*[@id=\"u_0j\"]/div");
//	By recent_login_pwd= By.xpath("//*[@id=\"pass\"]/div");
//	By pwd1= By.xpath("//*[@id=\"u_0j\"]/div");


	
WebDriver dr;
		public  AUT_login_page(WebDriver dr)
		{this.dr=dr;}
		
		public void set_uid(String un)
		{
			dr.findElement(uid).sendKeys(un);
		}
		
		public void set_pwd(String pword)
		{
			dr.findElement(pwd).sendKeys(pword);
			
		}
		
		public void clk_btn()
		{
			dr.findElement(btn).click();
		}
		
		public void do_login(String u, String p)
		{
			this.set_uid(u);
			this.set_pwd(p);
			this.clk_btn();
		}
		
		public String get_title()
		{
			return dr.getTitle();
		}
		
		


}
