package POM_testng;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import POM.AUT_homepage;
import POM.AUT_login_page;

public class test_AUT_login {
	
	WebDriver dr;
	AUT_login_page loginpage;
	AUT_homepage homepage;
	
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
	}
	
	
  @Test(priority=0)
  public void test_login_page() {
	  loginpage=new AUT_login_page(dr);
	  String login_page_title=loginpage.get_title();
	  Assert.assertTrue(login_page_title.contains("Shop"));
	  
  }
  
  @Test(priority=3)
  public void AUT_homepage() {
	  loginpage.do_login("balajigaddime@gmail.com", "Balaji@1996");
	  homepage=new AUT_homepage(dr);
	  
	  String actual_id=homepage.get_displayed_eid();
	  Assert.assertTrue(actual_id.contains("balajigaddime@gmail.com"));
	  
  }
}
