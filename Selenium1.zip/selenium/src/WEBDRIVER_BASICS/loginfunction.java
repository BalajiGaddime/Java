package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginfunction {
	static String eid, password;
	public static void login() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys(eid);
		
		dr.findElement(By.className("password")).sendKeys(password);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		eid="balajigaddime@gmail.com";
		password="Balaji@1996";
		loginfunction d=new loginfunction();
		d.login();

	}

}
