package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class excel1 {
	static String eid, password, act_res,exp_result,result;
	public static void login() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys(eid);
		
		dr.findElement(By.className("password")).sendKeys(password);
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		act_res=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
		dr.close();
		
	}

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		readexcel d=new readexcel();
		writeexcel f=new writeexcel();
		writeexcel g=new writeexcel();
		excel1 a= new excel1();

		String filename="C:\\Users\\BLTuser.BLT0191\\software\\demo.xlsx";
		String sheetname="Sheet2";
		
		int c=0;
		for (int r=1;r<=4;r++) {
		eid=d.getexcel( filename, sheetname, r, c);
		password=d.getexcel(filename, sheetname, r, 1);
		exp_result=d.getexcel(filename, sheetname, r, 2);
		a.login();
		
		
		if(exp_result.equals(act_res)==true) {
			result="pass";}
			else {
				result="fail";						
		}
		f.writeexcel(filename, sheetname, r, c, act_res, result);
		}}
		
		
		
		

	}

