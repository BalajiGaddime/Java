package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_inv_excel2 {
	static String s,id,q, password, act_em,exp_em,result ,act_em1;
	


		
		public static String login() {
			
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			WebDriver dr = new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com");
			dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
			dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys(id);
			
			dr.findElement(By.className("password")).sendKeys(password);
			dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
			q=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
			
			if(q.compareTo("Register")==0){
				if(id.isEmpty()==true) {
					String act_em=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
					String act_em1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
					String c=act_em+act_em1;
					dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
					dr.close();
					return c;
					
				}
				else {
					if(id.contains("@gmail.com")==false)
					{
						String act_em2=dr.findElement(By.xpath("//span[@class='field-validation-error']/span")).getText();
						dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
						dr.close();
						return act_em2;
					}
					else if(id.equals(" @gmail.com")==true)
					{
						String act_em2=dr.findElement(By.xpath("//span[@class='field-validation-error']/span")).getText();
						dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
						dr.close();
						return act_em2;
					}
					else
					{
						String act_em=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
						String act_em1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
						String c=act_em+act_em1;
						dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
						dr.close();
						return c;
					}
					
				}				 
				
			}
			else
			{
				dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
				dr.close();
				return q;
			}
			
			
			
			
			
		}

		public static void main(String[] args)  {
			// TODO Auto-generated method stub
			readexcel2 d=new readexcel2();
			Writeexcel2 f=new Writeexcel2();
//			writeexcel2 g=new writeexcel2();
			login_inv_excel2 a= new login_inv_excel2();

			String filename="C:\\Users\\BLTuser.BLT0191\\software\\demo.xlsx";
			String sheetname="Sheet3";
			
//			int c=0;
			String t;
			for (int r=1;r<=6;r++) {
			String p1=d.getexcel( filename, sheetname, r, 0);
			String p2=d.getexcel(filename, sheetname, r, 1);
			if(p1.equals("blank"))
			{
				id="";
				password="";
			}
			else
			{
				id=p1;
				password=p2;
			}
			exp_em=d.getexcel(filename, sheetname, r, 2);
			String m=a.login();
			f.writeexcel(filename, sheetname, r,3, m);
			
			int s=m.compareTo(exp_em);
			
			
			
			if(s==0)
			{
				t="pass";
			}
			else
			{
				t="fail";
			}
			f.writeexcel(filename, sheetname, r,4, t);
			
//			if(exp_result.equals(act_res)==true) {
//				result="pass";}
//				else {
//					result="fail";	
			
			
			}
			
			}
			
			
			
			


	}


