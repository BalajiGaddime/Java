package WEBDRIVER_BASICS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class extract_string {
	static String s;
	static int f;
	static String x=" ";
	static String m=" ";
	static String gender_ar=x;
	static String ag_ar=m;
	public static void extract()
	{
		int a=s.indexOf(':', 0);
		int g=s.indexOf('A', 0);
		int h=s.indexOf(':', g);
		//int d=s.indexOf('g', 1);
		 x = s.substring(a+=2, g=g-1);
		 m = s.substring(h+=2, f=s.length());
		 System.out.println(x);
		 System.out.println(m);
		 gender_ar=x;
		  ag_ar=m;
		 
		 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		
		/*dr.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[1]/label[1]/input")).click();
		dr.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[2]/label[2]/input")).click();
		dr.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/button")).click();
		String s=dr.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/p[2]")).getText();*/
		List ar=dr.findElements(By.name("gender"));
		((WebElement) ar.get(1)).click();
		List a=dr.findElements(By.name("ageGroup"));
		((WebElement) a.get(1)).click();
		dr.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/button")).click();
		 s=dr.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/p[2]")).getText();
		
		 extract_string.extract();
		 String gender_er="Female";
		 String ag_er="5 - 15";
		 if(gender_er.compareTo(gender_ar)==0) {
			 if(ag_er.compareTo(ag_ar)==0)
		 {
			 System.out.println("pass");
		 }}
			 

	}

}
