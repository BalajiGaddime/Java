package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//import selenium.ChromeDriver;
//import selenium.Webdriver;

public class amazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.amazon.in/");
		
		//dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("twotabsearchtextbox")).sendKeys("one plus 7t pro");
		//dr.findElement(By.className("password")).sendKeys("Balaji@1996");
		dr.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input")).click();
		dr.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[3]/div/span/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span")).click();
		//dr.findElement(By.id("small-searchterms")).sendKeys("mouse");
		//dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[2]")).click();*/

	}

}