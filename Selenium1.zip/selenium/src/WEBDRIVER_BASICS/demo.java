package WEBDRIVER_BASICS;

public class demo {
	static String s;
	static String p=" ";
	
/*	public static void extract()
	{
		int a=s.indexOf('.', 0);
		int b=s.indexOf('.', a=a+1);
		int l=s.length();
		p=s.substring(b, l);
		System.out.println(p);
		
	}*/

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 s="www.facebook.in";
		 int a=s.indexOf('.', 0);
			int b=s.indexOf('.', a=a+1);
			int l=s.length();
			p=s.substring(b, l);
			System.out.println(p);
		// demo.extract();
		

	}

}
