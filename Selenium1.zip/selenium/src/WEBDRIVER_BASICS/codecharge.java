package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class codecharge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		String login="guest";
		
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.xpath("//tr[@class='Controls'][1]/td[2]/input")).sendKeys(login);
		
	
		dr.findElement(By.xpath("//tr[@class='Controls'][2]/td[2]/input")).sendKeys("bgreddy");
		dr.findElement(By.xpath("//tr[@class='Controls'][3]/td[2]/input")).sendKeys("guest");
		dr.findElement(By.xpath("//tr[@class='Controls'][4]/td[2]/input")).sendKeys("guest");
		dr.findElement(By.xpath("//tr[@class='Controls'][5]/td[2]/input")).sendKeys("guest@gmail.com");
		dr.findElement(By.xpath("//tr[@class='Controls'][6]/td[2]/input")).sendKeys("hyd");
		dr.findElement(By.xpath("//tr[@class='Controls'][9]/td[2]/input")).sendKeys("hyd");
		
		WebElement we = dr.findElement(By.xpath("//tr[@class='Controls'][10]/td[2]/select"));

		Select sel=new Select(we);
		sel.selectByVisibleText("Alaska");
		
		dr.findElement(By.xpath("//tr[@class='Controls'][11]/td[2]/input")).sendKeys("45365");
		
		
		WebElement we1 = dr.findElement(By.xpath("//tr[@class='Controls'][12]/td[2]/select"));

		Select sel1=new Select(we1);
		sel1.selectByVisibleText("India");
		
		dr.findElement(By.xpath("//tr[@class='Controls'][13]/td[2]/input")).sendKeys("4564534");
		dr.findElement(By.xpath("//tr[@class='Controls'][14]/td[2]/input")).sendKeys("969558");
		
		WebElement we2 = dr.findElement(By.xpath("//tr[@class='Controls'][15]/td[2]/select"));

		Select sel2=new Select(we2);
		sel2.selectByVisibleText("English");
		
		WebElement we3 = dr.findElement(By.xpath("//tr[@class='Controls'][16]/td[2]/select"));

		Select sel3=new Select(we3);
		sel3.selectByVisibleText("18-24");
		
		WebElement we4 = dr.findElement(By.xpath("//tr[@class='Controls'][17]/td[2]/select"));

		Select sel4=new Select(we4);
		sel4.selectByVisibleText("Male");
		
		WebElement we5 = dr.findElement(By.xpath("//tr[@class='Controls'][18]/td[2]/select"));

		Select sel5=new Select(we5);
		sel5.selectByVisibleText("College");
		
		WebElement we6 = dr.findElement(By.xpath("//tr[@class='Controls'][19]/td[2]/select"));

		Select sel6=new Select(we6);
		sel6.selectByVisibleText("under $25,000");
		
		
		dr.findElement(By.xpath("//tr[@class='Controls'][20]/td[2]/textarea")).sendKeys("India is my country. All Indians are my brothers and sisters.");

		dr.findElement(By.xpath("//tr[@class='Bottom']/td/input[1]")).click();
		
		
		dr.findElement(By.xpath("//tr[@class='Controls']/td/input")).sendKeys(login);
		dr.findElement(By.xpath("/html/body/center/form/table/tbody/tr/td/table[2]/tbody/tr[2]/td[2]/input")).click();


		String a=dr.findElement(By.xpath("//tr[@class='Row']/td/a")).getText();
		
		if(a.compareTo(login)==0)
		{
			System.out.println("Registration successfully completed");
		}

		
		
	

	}

}
