package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class reading_table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		
		for(int r=2;r<=7;r++) {
			for(int c=1;c<=3;c++)
			{
				s = "//*[@id='customers']/tbody/tr["+r+"]/td["+c+"]";
				String str=dr.findElement(By.xpath(s)).getText();
				System.out.print(str+ " ");
			}	System.out.println();
		}
	

	}

}
