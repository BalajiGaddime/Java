package WEBDRIVER_BASICS;



import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class exception_handling2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
//		try {
//			WebDriverWait wt= new WebDriverWait(dr,10);
//			WebElement we=wt.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Log in")));
			
		
		try {
			dr.findElement(By.linkText("Log in1")).click();
		
		}catch (WebDriverException e) {
			System.out.println("An exceptional case");;
		}

//	}
//	catch(TimeoutException e) {
//		System.out.println("webdriver couldn't locate the webelement");
//	}
	System.out.println("webdriver continues execution");

}}
