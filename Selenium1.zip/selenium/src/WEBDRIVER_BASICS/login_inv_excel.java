package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_inv_excel {
	static String eid, password, act_em,exp_result,result;

	
public static void login() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys(eid);
		
		dr.findElement(By.className("password")).sendKeys(password);
		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
		act_em=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
		dr.close();
		
	}


public static String getexcel(String filename, String sheetname,int r,int c) {
	File f=new File(filename);
	String s= null;
	
	
	try {
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetname);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell = row.getCell(c);		
		
			eid = cell.getStringCellValue();
			
			
			XSSFRow row = sh.getRow(r);
			XSSFCell cell1 = row.createCell(3);
			XSSFCell cell2 = row.createCell(4);
			
			cell1.setCellValue(act_em);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			cell2.setCellValue(result);
			FileOutputStream fos1 = new FileOutputStream(f);
			wb.write(fos1);
			
		 
		
		
	}
	
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}
	
	
	

	
		public static void main(String[] args) {
//		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
//		WebDriver dr = new ChromeDriver();
//		dr.get("http://demowebshop.tricentis.com");
//		String id="";
//		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
//		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys(id);
//		
//		dr.findElement(By.className("password")).sendKeys("");
//		dr.findElement(By.xpath("//div[@class='form-fields']/form/div[5]/input")).click();
			login_inv_excel d=new login_inv_excel();
			String filename="C:\\Users\\BLTuser.BLT0191\\software\\demo.xlsx";
			String sheetname="Sheet2";

			int c=0;
			for (int r=1;r<=4;r++) {
			eid=d.getexcel( filename, sheetname, r, c);
			String password=d.getexcel(filename, sheetname, r, 1);
//			String ex_em=d.getexcel(filename, sheetname, r, 2);
			a.login();
		if( id.contains("@gmail.com")==true) {
		String act_em=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
		String act_em1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
		String ex_em="Login was unsuccessful. Please correct the errors and try again.";
		String ex_em1="The credentials provided are incorrect";
	
		
		
		if(act_em.equals(ex_em)==true) {
			System.out.println("actual error msg is:  " +act_em);
			System.out.println(act_em1);
			if(act_em1.equals(ex_em1)) {
				
				System.out.println("pass");
			}
			else
				System.out.println("fail");
		}
		else {
			String ex_em2="Please enter a valid email address.";
			String act_em2=dr.findElement(By.xpath("//span[@class='field-validation-error']/span")).getText();
			System.out.println("actual error msg is:  " +act_em2);
			if(act_em2.equals(ex_em2)==true) {
				
					System.out.println("pass");
				}
				else
					System.out.println("fail");
			
		}}
		if(id=="") {
			String ex_em3="No customer account found";
			String act_em=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
			String act_em3=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
			System.out.println("actual error msg is:  " +act_em);
			System.out.println( act_em3);
			if(act_em3.equals(ex_em3)==true) {
				
				System.out.println("pass");
			}
			else
				System.out.println("fail");
			
		}							
	}	
	}
