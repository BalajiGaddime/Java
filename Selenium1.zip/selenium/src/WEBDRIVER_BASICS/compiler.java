package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class compiler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.tutorialspoint.com/compile_java_online.php");
		
		dr.findElement(By.xpath("//*[@id=\"HelloWorld.java\"]/div[2]/div")).sendKeys("int num1 = 5, num2 = 15, sum; sum = num1 + num2;System.out.println(+sum);");

	}

}
