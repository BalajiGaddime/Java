package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class exception_handle3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String s=dr.getTitle();
		String q="Online Bookstore";
		if(s.compareTo(q)==0)
		{
			System.out.println("Title verified");
		}
		WebElement we = dr.findElement(By.xpath("//td[@width='250']/select"));

		Select sel=new Select(we);
		sel.selectByVisibleText("Databases");
		dr.findElement(By.xpath("//tr[@class='Bottom']/td/input")).click();
		dr.findElement(By.xpath("//table[@class='Grid']/tbody/tr[1]/td[2]/b/a[1]")).click();
		String d=dr.findElement(By.xpath("//td[@valign='top']/h1")).getText();
		String e="Web Database Development";
		if(d.compareTo(e)==0)
		{
			System.out.println("Product name verified");
		}
		else {
			System.out.println("Product name not verified");

		}
		
		String w=dr.findElement(By.xpath("//table[@border='0']/tbody/tr/td[2]")).getText();
		System.out.println("Price is:  " +w);

		dr.findElement(By.xpath("//form[@name='add_to_cart']/p[1]/input[1]")).clear();
		dr.findElement(By.xpath("//form[@name='add_to_cart']/p[1]/input[1]")).sendKeys("2");
		String a=dr.findElement(By.xpath("//form[@name='add_to_cart']/p[1]/input[1]")).getAttribute("value");
		System.out.println("quantity is " +a);

		dr.findElement(By.xpath("//form[@name='add_to_cart']/p[2]/input[1]")).click();
		
		String total=dr.findElement(By.xpath("//table[@class='Grid']/tbody/tr[2]/td[4]")).getText();
		System.out.println("total price is " +total );
		String u="$79.98";
		if(total.compareTo(u)==0)
		{
			System.out.println("Price is verified");
		}
		else {
			System.out.println("Price not is verified");}
		

		

	}

}
