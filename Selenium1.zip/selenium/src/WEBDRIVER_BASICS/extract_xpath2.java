package WEBDRIVER_BASICS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import selenium.ChromeDriver;
//import selenium.Webdriver;

public class extract_xpath2 {

	public static void main(String[] args) throws InterruptedException {
		int i=4;
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String xp="//div[@class='item-box'][3]//child::input";
		String xp1="//div[@class='item-box'][3]//child::input1";
//		WebElement we;
//		WebDriverWait wt= new WebDriverWait(dr,10);
//		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp)));
//		we.click();
		
		
		//dr.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys("balajigaddime@gmail.com");
		
		dr.findElement(By.className("password")).sendKeys("Balaji@1996");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		dr.findElement(By.xpath("//ul[@class='top-menu']/li[2]/a")).click();
		dr.findElement(By.xpath("//div[@class='item-box'][3]/div/h2/a")).click();
		
		
		dr.findElement(By.xpath("//div[@class='item-box'][2]//child::input")).click();
//		TimeUnit.SECONDS.sleep(4);
		
		WebElement we;
		WebDriverWait wt= new WebDriverWait(dr,10);
		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp)));
		we.click();
//		dr.findElement(By.xpath("//div[@class='item-box'][3]//child::input")).click();
		TimeUnit.SECONDS.sleep(4);

		
		dr.findElement(By.xpath("//div[@class='item-box'][4]//child::input")).click();
		TimeUnit.SECONDS.sleep(4);
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[3]/a")).click();
		dr.findElement(By.xpath("//table[@class='cart']/tbody/tr[1]/td[1]/input")).click();
		
		
		String p=dr.findElement(By.xpath("//table[@class='cart']/tbody/tr[1]/td[3]/a")).getText();//product name
		String q=dr.findElement(By.xpath("//table[@class='cart']/tbody/tr[1]/td[4]/span[2]")).getText();//product price
		String l=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/table/tbody/tr[2]/td[5]/input")).getAttribute("value");
		System.out.println(p);
		System.out.println(q);
		System.out.println(l);

		System.out.println("product is succefully removed");
		
		
		dr.findElement(By.xpath("//div[@class='common-buttons']/input[1]")).click();
		
		
		
		
		
		
	}}