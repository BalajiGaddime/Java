package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demoshop_xpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		//label[(text()='Email:')]
		//label[(text()='Password:')]
		//label[(text()='Remember me?')]
		
		
		//label[contains(text(),'Em')]
		//label[contains(text(),'Pass')]
		//label[contains(text(),'Remember')]
		
		
		//div[contains(@class,'inp')][1]/input
		//div[contains(@class,'inp')][2]/input
		//div[contains(@class,'butt')]//input[contains(@value, 'Log')]
		
		
		
		//div[@class='inputs'][1]//child::input
		//div[@class='inputs'][2]//child::input
		//input[contains(@value, 'Log in')]

	}

}
