package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public  class readexcel extends excel1{
	
	public String getexcel(String filename, String sheetname,int r,int c) {
	File f=new File(filename);
	String s= null;
	
	
	try {
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetname);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell = row.getCell(c);
		
		
	
		
		
		 s = cell.getStringCellValue();
		 
		
		
	}
	
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s;
	
}}