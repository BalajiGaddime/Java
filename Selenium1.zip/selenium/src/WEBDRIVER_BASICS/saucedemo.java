package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class saucedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String id="standard_user";
		String password="secret_sauce";
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		try {
		dr.get("https://www.google.com/search?q=saucedemo&oq=saucedemo&aqs=chrome..69i57.105282j0j7&sourceid=chrome&ie=UTF-8");} catch(NoSuchElementException e) {}
		try {
		dr.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div[1]/a")).click();} catch(NoSuchElementException e) {}
		try {
		dr.findElement(By.xpath("//div[@class='login-box']/form[1]/input[1]")).sendKeys(id);} catch(NoSuchElementException e) {}
		try {
		dr.findElement(By.xpath("//div[@class='login-box']/form[1]/input[2]")).sendKeys(password);} catch(NoSuchElementException e) {}
		try {
		dr.findElement(By.xpath("//div[@class='login-box']/form[1]/input[3]")).click();} catch(NoSuchElementException e) {}
		
		
		String expname1=dr.findElement(By.xpath("//div[@class='inventory_list']/div[1]/div[2]/a/div")).getText();//name of first product
		String expprice1=dr.findElement(By.xpath("//div[@class='inventory_list']/div[1]/div[3]/div")).getText();//price of first product
		int a=expprice1.indexOf('$', 0);
		int b=expprice1.length();
				String p1=expprice1.substring(a=a+1, b);
				System.out.println(p1);
		String expname2=dr.findElement(By.xpath("//div[@class='inventory_list']/div[2]/div[2]/a/div")).getText();//name of second product
		
		String expprice2=dr.findElement(By.xpath("//div[@class='inventory_list']/div[2]/div[3]/div")).getText();//price of first product
		int a1=expprice2.indexOf('$', 0);
		int b1=expprice2.length();
				String p2=expprice2.substring(a1=a1+1, b1);
				System.out.println(p2);
				
		
		dr.findElement(By.xpath("//div[@class='inventory_list']/div[1]/div[3]/button")).click();  //add to cart p1
		dr.findElement(By.xpath("//div[@class='inventory_list']/div[2]/div[3]/button")).click();  //add to cart p1
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']/a")).click();

		
		String actpname1=dr.findElement(By.xpath("//div[@class='cart_item'][1]/div[2]/a/div")).getText();//name of first product
		String actprice1=dr.findElement(By.xpath("//div[@class='cart_item'][1]/div[2]/div[2]/div")).getText();//price of first product
		String actpname2=dr.findElement(By.xpath("//div[@class='cart_item'][2]/div[2]/a/div")).getText();//name of first product
		String actprice2=dr.findElement(By.xpath("//div[@class='cart_item'][2]/div[2]/div[2]/div")).getText();//price of first product

		if(expname1.compareTo(actpname1)==0)
		{
			System.out.println("product 1 name is verified");
		}
		if(p1.compareTo(actprice1)==0)
		{
			System.out.println("product 1 price is verified");

		}
		if(expname2.compareTo(actpname2)==0)
		{
			System.out.println("product 2 name is verified");
		}
		if(p2.compareTo(actprice2)==0)
		{
			System.out.println("product 2 price is verified");

		}
		if(expname1.compareTo(actpname1)==0 && p1.compareTo(actprice1)==0 && expname2.compareTo(actpname2)==0 && p2.compareTo(actprice2)==0)
		{
			System.out.println("All pass");
		}
		else {
			System.out.println("fail");
		}
		
	}

}
