package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class writeexcel extends excel1{
	
	public void writeexcel(String filename, String sheetname2, int r, int c, String act_res, String result) {
		File f=new File(filename);
		try {
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetname2);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell1 = row.createCell(3);
		XSSFCell cell2 = row.createCell(4);
		
		cell1.setCellValue(act_res);
		FileOutputStream fos = new FileOutputStream(f);
		wb.write(fos);
		cell2.setCellValue(result);
		FileOutputStream fos1 = new FileOutputStream(f);
		wb.write(fos1);
		
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
