package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//import selenium.ChromeDriver;
//import selenium.Webdriver;

public class xpath_creation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String e="balajigaddime@gmail.com";
		
		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
		dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys("balajigaddime@gmail.com");
		
//		dr.findElement(By.className("password")).sendKeys("Balaji@1996");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		String s=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/span")).getText();
		System.out.println(s);
		String p=dr.findElement(By.xpath("//div[@class='validation-summary-errors']/ul/li")).getText();
		System.out.println(p);
//		if(e.compareTo(s)==0) {
//		System.out.println("pass");
//		}
		
	}}