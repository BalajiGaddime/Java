package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Writeexcel2 extends login_inv_excel2{
	
	public void writeexcel(String filename, String sheetname, int r, int c, String act_em) {
		File f=new File(filename);
		try {
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetname);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell = row.createCell(c);
		

		
		
		cell.setCellValue(act_em);
		FileOutputStream fos11 = new FileOutputStream(f);
		wb.write(fos11);
		
	
		
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
