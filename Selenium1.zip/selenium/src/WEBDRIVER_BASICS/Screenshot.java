package WEBDRIVER_BASICS;





import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;




public class Screenshot {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2=new File("C:\\Users\\BLTuser.BLT0191\\software\\screeshot.png");
		FileUtils.copyFile(f1, f2);
		
		

	}

}
