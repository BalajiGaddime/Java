package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class demosauce_login {
	WebDriver dr;
	@FindBy(xpath="//input[@class='form_input'][1]")
	WebElement uname;
	
	@FindBy(xpath="//input[@class='form_input'][2]")
	WebElement pword;
	
	@FindBy(xpath="//input[@class='btn_action']")
	WebElement btn;
	

	public void set_un(String un)
	{
		uname.sendKeys(un);
	}


	public void set_pword(String pwd)
	{
		pword.sendKeys(pwd);
	}

	public void clk_btn()
	{
		btn.click();
	}
	public demosauce_login(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void do_login(String u, String p)
	{
		this.set_un(u);
		this.set_pword(p);
		this.clk_btn();
	}




public String title()
{
	return dr.getTitle();
	
}



}
