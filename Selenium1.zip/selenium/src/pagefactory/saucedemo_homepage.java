package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class saucedemo_homepage {
	WebDriver dr;
	
	@FindBy(xpath="//div[@class='product_label']")
	WebElement product;
	
	@FindBy(xpath="//a[@id='item_4_title_link'][1]/div")
	WebElement p_name;

	public saucedemo_homepage(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}


public String p_lable()
{
	
	String act_plable=product.getText();
	
	return act_plable;
}

public String pname()
{
	return p_name.getText();
}







}