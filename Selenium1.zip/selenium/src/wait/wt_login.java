package wait;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class wt_login {
	static wait_types wt;
	WebDriver dr;
	
	public wt_login(WebDriver dr) {
		this.dr=dr;
		// TODO Auto-generated constructor stub
	}

	public void login(String uid, String pword)
	{
		wt=new wait_types(dr);
		By eid=By.xpath("//*[@id='Email']");
		WebElement we_eid= wt.waitForElement(eid, 20);
		we_eid.sendKeys(uid);
		
		By pwd=By.xpath("//*[@id='Password']");
		WebElement we_pwd= wt.waitForElement(pwd, 20);
		we_pwd.sendKeys(pword);
		
		By btn=By.xpath("//input[@value='Log in']");
		WebElement we_btn= wt.elementToBeClickable(btn, 20);
		we_btn.click();
		
		
	}

}
