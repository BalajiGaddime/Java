package wait;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class wait_types_testng {
	WebDriver dr;
	wt_login a;
	
	@BeforeClass
	public void lb() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr=new  ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
  @Test
  public void login () {
	  a= new wt_login(dr);
	  a.login("balajigaddime@gmail.com", "Balaji@1996");
  }
}
