package Action_class;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class handling_holdkeys_actionclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		
		WebElement email=dr.findElement(By.xpath("//div[@class='inputs']/input"));
		WebElement search=dr.findElement(By.className("password"));
		email.sendKeys("chennai");
		Actions kb=new Actions(dr);
		
		kb
		.keyDown(email, Keys.SHIFT)
		.sendKeys(email, "chennai")
		.keyUp(email, Keys.SHIFT)
		.build()
		.perform();

		
	}

}
