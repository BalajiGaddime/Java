package Textng;

import org.testng.annotations.Test;

public class p1 {
  @Test
  public void f() {
	  System.out.println("hi");
  }
}
