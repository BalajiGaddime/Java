package Textng;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class demosauce_reg_fun {
	
	WebDriver dr;
	 String p,q;

	
	public void register (String firstname, String lastname,String email,String password,String comfirmpassword) throws IOException
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	dr = new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
   dr.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]")).click();
	
	
	List ar=dr.findElements(By.xpath("//div[@class='form-fields']/div/div[1]/input"));
	((WebElement) ar.get(0)).click(); 
	
	dr.findElement(By.xpath("//div[@class='form-fields']/div[2]/input[@name='FirstName']")).sendKeys(firstname);
	dr.findElement(By.xpath("//div[@class='form-fields']/div[3]/input[@name='LastName']")).sendKeys(lastname);
	dr.findElement(By.xpath("//div[@class='form-fields']/div[4]/input[@name='Email']")).sendKeys(email);
	dr.findElement(By.xpath("//input[@id='Password']")).sendKeys(password);
	dr.findElement(By.xpath("//input[@id='ConfirmPassword']")).sendKeys(comfirmpassword);
	dr.findElement(By.xpath("//input[@id='register-button']")).click();


}}
