package Textng;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login1 extends read_excel_dataprovider  {
	loginfun_dataprovider1 a= new loginfun_dataprovider1();
	
	@BeforeClass
	public void get_data() throws FileNotFoundException
	{
		get_testdata();
	}
	  @Test(dataProvider="login_data")
	  public void t1(String eid, String password, String exp_id) {
		  
		  String act_id=a.login(eid, password);
		  SoftAssert sa= new SoftAssert();
		  sa.assertEquals(act_id, exp_id);
		  sa.assertAll();
	  }
	  @DataProvider(name="login_data")
	  public String[][] provide_data()
	  {
		  
		  
		 return testdata1;
	  }
}
