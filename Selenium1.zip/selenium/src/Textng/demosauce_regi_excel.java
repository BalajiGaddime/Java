package Textng;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class demosauce_regi_excel extends demosauce_regi_func_excel {
	demosauce_regi_func_excel a= new demosauce_regi_func_excel();
	
	
	
	
	
	
	
	@BeforeClass
	public void f1() throws FileNotFoundException {
		  
		  a.get_testdata();
	  }
	
//	(invocationCount =3)
  @Test(dataProvider="reg_data")
  public void register(String firstname,String  lastname,String email,String password,String comfirmpassword, String exp_res) throws IOException
	{
		
	a.register(firstname,lastname,email,password,comfirmpassword);
	
	 SoftAssert sa= new SoftAssert();
	  sa.assertEquals(exp_res, act_res);
	  sa.assertAll();
	
	}
  
  @DataProvider(name="reg_data")
  public String[][] provide_data()
  {
	 
	  return testdata1;
  }
}
