package Textng;

import org.testng.annotations.Test;

public class priority {
	  @Test(priority= 20)
	  public void india() {
		  System.out.println("hi");
		  
	  }
	  @Test(priority= 5)
	  public void mumbai() {
		  System.out.println("hi");
	  }
	  @Test(priority= 10)
	  public void pune() {
		  System.out.println("hi");
	  }
}
