package Textng;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assert {
  @Test
  public void f1() {
	  String er="chennai", ar="chennai";
	  System.out.println("in test method f1");
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
  @Test
  public void f2() {
	  String er="chennai", ar="chennai1";
	  System.out.println("in test method f2");
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
}
