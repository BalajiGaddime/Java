package Textng;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	
	loginfun_dataprovider a= new loginfun_dataprovider();
  @Test(dataProvider="login_data")
  public void t1(String eid, String password, String exp_id) {
	  
	  String act_id=a.login(eid, password);
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(act_id, exp_id);
	  sa.assertAll();
  }
  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
	  String[][] data= {{"balajigaddime@gmail.com", "Balaji@1996", "balajigaddime@gmail.com"},{"balajigaddime@gmail.com", "Balajdi@1996", "balajigaddime@gmail.com"}};
	  return data;
  }
}
