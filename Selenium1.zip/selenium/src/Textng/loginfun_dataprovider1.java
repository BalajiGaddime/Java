package Textng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginfun_dataprovider1 {
	WebDriver dr;
	
	
	public String login(String eid, String password)
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	dr = new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]")).click();
	dr.findElement(By.xpath("//div[@class='inputs']/input")).sendKeys(eid);
	
	dr.findElement(By.className("password")).sendKeys(password);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	String act_id=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
	return act_id;
	}



	}


