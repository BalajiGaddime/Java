package Textng;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class verify_product_saucedemo  {
	
	public void verify(String expname1, String actpname1,int m)
	{
//		if(expname1.equals(actpname1)==true)
//		{
//			System.out.println("product" +m+" name is verified");
//		}
//		else {
//			System.out.println("not verified");}
//		if(expname2.equals(actpname2)==true)
//		{
//			System.out.println("product 2 name is verified");
//		}
//		else {
//			System.out.println("not verified");}
		
		
		 @Test
		  public void f1() {
			  System.out.println("in test method t1");
			  SoftAssert sa= new SoftAssert();
			  sa.assertEquals(expname1, actpname1);
			  sa.assertAll();
		  }
	}

}
 