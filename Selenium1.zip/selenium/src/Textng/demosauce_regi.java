package Textng;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class demosauce_regi extends demosauce_reg_fun {
	demosauce_reg_fun a= new demosauce_reg_fun();
	
	
	
	
	
	
	
	
	
//	(invocationCount =3)
  @Test(dataProvider="reg_data")
  public void register(String firstname,String  lastname,String email,String password,String comfirmpassword) throws IOException
	{
		
	a.register(firstname,lastname,email,password,comfirmpassword);
	
	}
  
  @DataProvider(name="reg_data")
  public String[][] provide_data()
  {
	 
	  String[][] data= {{"balaji", "reddy", "bg@gmail.com","bgreddy","bgreddy"}};
	  return data;
  }
}
