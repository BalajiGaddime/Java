package Textng;

import org.testng.annotations.Test;

public class sleep {
  @Test
  public void f1() {
	  System.out.println("in f1: before");
	
		  try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  System.out.println("in f1: after");
  }
  @Test
  public void f2() {
	  System.out.println("in f2: before");
	
		  try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  System.out.println("in f2: after");

  }
}
