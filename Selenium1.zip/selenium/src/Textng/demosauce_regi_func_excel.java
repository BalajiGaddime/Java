package Textng;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class demosauce_regi_func_excel {
	
		WebDriver dr;
		 String p,q;
		 static String act_res;
		
		public void register (String firstname, String lastname,String email,String password,String comfirmpassword) throws IOException
		{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
	    dr.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]")).click();
		
		
		List ar=dr.findElements(By.xpath("//div[@class='form-fields']/div/div[1]/input"));
		((WebElement) ar.get(0)).click(); 
		
		
		dr.findElement(By.xpath("//div[@class='form-fields']/div[2]/input[@name='FirstName']")).sendKeys(firstname);
		dr.findElement(By.xpath("//div[@class='form-fields']/div[3]/input[@name='LastName']")).sendKeys(lastname);
		dr.findElement(By.xpath("//div[@class='form-fields']/div[4]/input[@name='Email']")).sendKeys(email);
		dr.findElement(By.xpath("//input[@id='Password']")).sendKeys(password);
		dr.findElement(By.xpath("//input[@id='ConfirmPassword']")).sendKeys(comfirmpassword);

		  p=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();

		
		dr.findElement(By.xpath("//input[@id='register-button']")).click();
		
		 q=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();
		 
		
				
					
					if(p.compareTo(q)==0) {
					File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
					File f2=new File("C:\\Users\\BLTuser.BLT0191\\software\\screeshot11.png");
					FileUtils.copyFile(f1, f2);}
					else {					
					File f3=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
					File f4=new File("C:\\Users\\BLTuser.BLT0191\\software\\screeshot11.png");
					FileUtils.copyFile(f3, f4);}
				act_res=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[1]/div/ul/li")).getText();
					

				}
		 

//		String act_id=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]/a")).getText();


		
		
		
		static String[][] testdata1= new String[2][6];
		int r,c;
		
		public void get_testdata() throws FileNotFoundException  {
		
		
		
		try {
			
			File f=new File("C:\\Users\\BLTuser.BLT0191\\software\\demo.xlsx");

			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			for(r=0;r<2;r++) {
				XSSFRow row = sh.getRow(r);
//				for(c=0;c<5;r++) {				
					XSSFCell cell1 = row.getCell(0);
//					testdata1[r][c] =cell1.getStringCellValue();
//					System.out.println(d);
//					testdata1[r][c]=d;
//					System.out.println(testdata1[r][c]);
			
			testdata1[r][0]=cell1.getStringCellValue();
			System.out.println(testdata1[r][0]);

			XSSFCell cell2 = row.getCell(1);
			testdata1[r][1]=cell2.getStringCellValue();
			System.out.println(testdata1[r][1]);

			XSSFCell cell3 = row.getCell(2);
			testdata1[r][2]=cell3.getStringCellValue();
			System.out.println(testdata1[r][2]);

			XSSFCell cell4 = row.getCell(3);
			testdata1[r][3]=cell4.getStringCellValue();
			System.out.println(testdata1[r][3]);
			
			
			XSSFCell cell5 = row.getCell(4);
			testdata1[r][4]=cell4.getStringCellValue();
			System.out.println(testdata1[r][4]);
			
			XSSFCell cell6 = row.getCell(5);
			testdata1[r][5]=cell6.getStringCellValue();
			System.out.println(testdata1[r][5]);
			String exp_res=testdata1[r][5];
			
			 
			
			
		}}
		
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
		
		

			

}
