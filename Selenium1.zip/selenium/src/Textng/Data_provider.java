package Textng;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Data_provider {
  @Test(dataProvider="login_data")
  public void login(String eid, String pwd, String exp_res) {
	  System.out.println(  "  emailid  :" +eid+ "  password  :" +pwd+ "  exp res  :" +exp_res);
  }
  
  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
	  String[][] data= {{"e1", "p1", "er1"},{"e2", "p2", "er2"},{"e2", "p2", "er2"}};
	  return data;
  }
}
