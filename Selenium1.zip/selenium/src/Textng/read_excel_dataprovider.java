package Textng;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class read_excel_dataprovider  {
	static String[][] testdata1= new String[2][3];
	int r,c;
	
	public void get_testdata() throws FileNotFoundException  {
	
	
	
	try {
		
		File f=new File("C:\\Users\\BLTuser.BLT0191\\software\\demo.xlsx");

		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("testdata");
		for(r=0;r<2;r++) {
			XSSFRow row = sh.getRow(r);
			for(c=0;c<3;r++) {				
				XSSFCell cell1 = row.getCell(c);
				String d =cell1.getStringCellValue();
				System.out.println(d);
				testdata1[r][c]=d;
				System.out.println(testdata1[r][c]);
		
//		testdata[rowno][0]=cell1.getStringCellValue();
//		XSSFCell cell2 = row.getCell(1);
//		testdata[rowno][1]=cell2.getStringCellValue();
//		XSSFCell cell3 = row.getCell(1);
//		testdata[rowno][2]=cell3.getStringCellValue();
		 
		
		
	}}}
	
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}}
	
	



